﻿using System;
using CardClasses;

namespace BlackJackHand_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
